# Video-Stitching
<img src="res/img/Blockdiagram.jpg">
